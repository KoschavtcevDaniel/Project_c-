﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Npgsql;


namespace Winner2
{
    public partial class Naclad : Form
    {
        public NpgsqlConnection con;
        DataTable dt = new DataTable();
        DataSet ds = new DataSet();
        int id;
        int id_client;
        int id_tovar;
        public Naclad(NpgsqlConnection con)
        {
            InitializeComponent();
            this.con = con;
        }

        private void Naclad_Load(object sender, EventArgs e)
        {
            Update();
        }
        public void Update()
        {
            String sql = "Select * from contract";
            NpgsqlDataAdapter da = new NpgsqlDataAdapter(sql, con);
            ds.Reset();
            da.Fill(ds);
            dt = ds.Tables[0];
            dataGridView1.DataSource = dt;
            dataGridView1.Columns[0].HeaderText = "Номер контракта";
            dataGridView1.Columns[1].HeaderText = "Дата";
            dataGridView1.Columns[2].HeaderText = "ID клиента";
            dataGridView1.Columns[3].HeaderText = "Сумма";
            dataGridView1.Columns[4].HeaderText = "Предоплата";
            dataGridView1.Columns[5].HeaderText = "Сумма отгруженного";
            this.StartPosition = FormStartPosition.CenterScreen;
            List<Client> list = new List<Client>();
            string request = "SELECT id_c, name_ FROM client";
            NpgsqlCommand cmd = new NpgsqlCommand(request, con);
            using (NpgsqlDataReader reader = cmd.ExecuteReader())
            {
                while (reader.Read())
                {
                    string str = reader["id_c"].ToString();
                    int id_c = Convert.ToInt32(str);
                    string name = reader["name_"].ToString();
                    Client client = new Client(id_c, name);
                    list.Add(client);  
                }
            }
            comboBox1.DataSource = list;
            comboBox1.DisplayMember = "name_";
            comboBox1.ValueMember = "id_c";
        }

        private void dateTimePicker1_ValueChanged(object sender, EventArgs e)
        {

        }

        public class Client
        {
            public int id { get; set; }
            public string name { get; set; }

            public Client(int id, string name)
            {
                this.id = id;
                this.name = name;
            }
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            Client client = (Client)comboBox1.SelectedItem;
            id_client = client.id;

        }

        private void updateToolStripMenuItem_Click(object sender, EventArgs e)
        {
            string sql = string.Format("UPDATE contract SET date_cnt = '{0}', id_client = {1}, sum_cnt = {2}, prepayment = {3}, sum_sh = {4} where id_cnt = {5}", dateTimePicker1.Value, id_client, Convert.ToInt32(textBox2.Text), Convert.ToInt32(checkBox1.Checked.ToString()), Convert.ToInt32(textBox5.Text), id);
            NpgsqlCommand com = new NpgsqlCommand(sql, con);
            com.ExecuteNonQuery();
            Update();
        }

        private void deleteToolStripMenuItem_Click_1(object sender, EventArgs e)
        {
            const string message = "Ты головой подумал?";
            const string caption = "Form Closing";
            var result = MessageBox.Show(message, caption, MessageBoxButtons.YesNo, MessageBoxIcon.Question);

            // If the no button was pressed ...
            if (result == DialogResult.Yes)
            {
                int id = (int)dataGridView1.CurrentRow.Cells["id_info"].Value;
                NpgsqlCommand command = new NpgsqlCommand("Delete from contract where id_cnt = :id", con);
                command.Parameters.AddWithValue("id", id);
                command.ExecuteNonQuery();
                Update();
            }
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void addToolStripMenuItem_Click(object sender, EventArgs e)
        {
            NpgsqlCommand com = new NpgsqlCommand("INSERT INTO contract (data_inf, id_client, sum_cnt, prepayment, sum_sh) VALUES (:data_inf, :id_client, :sum_cnt, :prep, :sum_sh)", con);
            com.Parameters.AddWithValue("data_inf", dateTimePicker1.Value);
            com.Parameters.AddWithValue("id_client", id_client);
            com.Parameters.AddWithValue("sum_cnt", Convert.ToInt32(textBox2.Text));
            com.Parameters.AddWithValue("prep", Convert.ToInt32(checkBox1.Checked.ToString()));
            com.Parameters.AddWithValue("sum_sh", Convert.ToInt32(textBox5.Text));
            com.ExecuteNonQuery();
            Update();
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        public class Tovar
        {
            public int id { get; set; }
            public string name { get; set; }

            public Tovar(int id, string name)
            {
                this.id = id;
                this.name = name;
            }
        }

        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {
            Tovar tovar = (Tovar)comboBox2.SelectedItem;
            id_tovar = tovar.id;
        }

        DataTable dt2 = new DataTable();
        DataSet ds1 = new DataSet();
    

        private void textBox3_TextChanged(object sender, EventArgs e)
        {
             
        }

        private void button1_Click(object sender, EventArgs e)
        {
            NpgsqlCommand command = new NpgsqlCommand("INSERT INTO cnt_decoding(id_p,id_cnt,quantity,sum_dec) VALUES (:id_tovar, :id_cnt, :quant, :sum)", con);
            command.Parameters.AddWithValue("quant", Convert.ToInt32(textBox3.Text));
            command.Parameters.AddWithValue("sum", Convert.ToInt32(textBox1.Text));
            command.Parameters.AddWithValue("id_tovar", id_tovar);
            command.Parameters.AddWithValue("id_cnt", id);
            command.ExecuteNonQuery();
            Update_info();
        }

        public void Update_info()
        {
            String sql = "Select * from cnt_decoding";
            NpgsqlDataAdapter da = new NpgsqlDataAdapter(sql, con);
            ds.Reset();
            da.Fill(ds);
            dt = ds.Tables[0];
            dataGridView2.DataSource = dt;
            dataGridView2.Columns[0].HeaderText = "Номер контракта";
            dataGridView2.Columns[1].HeaderText = "Номер клиента";
            dataGridView2.Columns[2].HeaderText = "Кол-во";
            dataGridView2.Columns[3].HeaderText = "Сумма";
            this.StartPosition = FormStartPosition.CenterScreen;
            List<Client> list = new List<Client>();
            string request = "SELECT id_p, name_p FROM product";
            NpgsqlCommand cmd = new NpgsqlCommand(request, con);
            using (NpgsqlDataReader reader = cmd.ExecuteReader())
            {
                while (reader.Read())
                {
                    string str = reader["id_p"].ToString();
                    int id_c = Convert.ToInt32(str);
                    string name = reader["name_p"].ToString();
                    Client client = new Client(id_c, name);
                    list.Add(client);
                }
            }
            comboBox2.DataSource = list;
            comboBox2.DisplayMember = "name_p";
            comboBox2.ValueMember = "id_p";
        }

        private void dg_SelectionChanged_1(object sender, EventArgs e)
        {
            DataGridViewSelectedRowCollection selectedRows = dataGridView1.SelectedRows;
            if (selectedRows.Count > 0)
            {
                DataGridViewRow row = selectedRows[0];
                id = Convert.ToInt32(row.Cells[0].Value);
            }
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void label8_Click(object sender, EventArgs e)
        {

        }
    }
}
