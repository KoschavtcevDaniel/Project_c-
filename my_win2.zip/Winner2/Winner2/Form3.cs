﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Npgsql;

namespace Winner2
{
    public partial class Form3 : Form
    {
        public NpgsqlConnection con;
        public Form3(NpgsqlConnection con)
        {
            InitializeComponent();
            this.con = con;
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                NpgsqlCommand command = new NpgsqlCommand("INSERT INTO product (name_p, merge_p) VALUES (:name, :ed)", con);
                command.Parameters.AddWithValue("name", textBox1.Text);
                command.Parameters.AddWithValue("ed", textBox2.Text);
                command.ExecuteNonQuery();
                Close();
            }
            catch {}
        }

    }
}
