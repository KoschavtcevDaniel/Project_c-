﻿using Npgsql;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Npgsql;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;
using System.Security.Cryptography;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.Button;

namespace Winner2
{
    public partial class Summary : Form
    {
        public NpgsqlConnection con;
        DataTable dt = new DataTable();
        DataSet ds = new DataSet();
        int id_p;
        int id_cnt;
        
        public Summary(NpgsqlConnection con)
        {
            this.con = con;
            InitializeComponent();
        }

        
        public void Update()
        {
            String sql = "Select client.*, contract.sum_cnt, contract.sum_sh, contract.prepayment from client, contract";
            NpgsqlDataAdapter da = new NpgsqlDataAdapter(sql, con);
            ds.Reset();
            da.Fill(ds);
            dt = ds.Tables[0];
            dataGridView1.DataSource = dt;
            dataGridView1.Columns[0].HeaderText = "Номер";
            dataGridView1.Columns[1].HeaderText = "Имя";
            dataGridView1.Columns[2].HeaderText = "Адрес";
            dataGridView1.Columns[3].HeaderText = "Телефон";
            dataGridView1.Columns[4].HeaderText = "Сумма общая";
            dataGridView1.Columns[5].HeaderText = "Сумма отгруженная";
            this.StartPosition = FormStartPosition.CenterScreen;
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void Summary_Load(object sender, EventArgs e)
        {
            Update();
        }
        public class Client
        {
            public int id { get; set; }
            public string name { get; set; }

            public Client(int id, string name)
            {
                this.id = id;
                this.name = name;
            }
        }
        private void dg_SelectionChanged_1(object sender, EventArgs e)
        {
            DataGridViewSelectedRowCollection selectedRows = dataGridView1.SelectedRows;
            List<Client> list = new List<Client>();
            string request = "SELECT id_c, name_ FROM client";
            NpgsqlCommand cmd = new NpgsqlCommand(request, con);
            using (NpgsqlDataReader reader = cmd.ExecuteReader())
            {
                while (reader.Read())
                {
                    string str = reader["id_c"].ToString();
                    int id_c = Convert.ToInt32(str);
                    string name = reader["name_"].ToString();
                    Client client = new Client(id_c, name);
                    list.Add(client);
                }
            }
            if (selectedRows.Count > 0)
            {
                DataGridViewRow row = selectedRows[0];
                id_cnt = Convert.ToInt32(row.Cells[0].Value);
                
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {

        }
    }
}
