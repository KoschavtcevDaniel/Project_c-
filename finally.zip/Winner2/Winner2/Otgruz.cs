﻿using Npgsql;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Npgsql;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;
using System.Net.Sockets;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.Button;
using Excel = Microsoft.Office.Interop.Excel;

namespace Winner2
{
    public partial class Otgruz : Form
    {
        public NpgsqlConnection con;
        DataTable dt = new DataTable();
        DataSet ds = new DataSet();
        DataTable dt1 = new DataTable();
        DataSet ds1 = new DataSet();
        int id_p;
        int id_cnt;
        public Otgruz(NpgsqlConnection con)
        {
            this.con = con;
            InitializeComponent();
        }

        public void Update(int id_cn)
        {
            List<Naclad> list = new List<Naclad>();
            string request = "select id_cnt from contract";
            NpgsqlCommand com = new NpgsqlCommand(request, con);
            using (NpgsqlDataReader reader = com.ExecuteReader())
            {
                while (reader.Read())
                {
                    string str = reader["id_cnt"].ToString();
                    int id_cnt = Convert.ToInt32(str);
                    Naclad contr = new Naclad(id_cnt);
                    list.Add(contr);
                }
            }
            comboBox1.DataSource = list;
            comboBox1.ValueMember = "id_cnt";

            String sql = "Select * from cnt_decoding where id_cnt="+id_cn;
            NpgsqlDataAdapter da = new NpgsqlDataAdapter(sql, con);
            ds.Reset();
            da.Fill(ds);
            dt = ds.Tables[0];
            dataGridView1.DataSource = dt;
            dataGridView1.Columns[0].HeaderText = "Номер продукта";
            dataGridView1.Columns[1].HeaderText = "Номер контракта";
            dataGridView1.Columns[2].HeaderText = "Количество";
            dataGridView1.Columns[3].HeaderText = "Сумма";

            String sql1 = "Select * from shipment where id_cnt=" + id_cn;
            NpgsqlDataAdapter da1 = new NpgsqlDataAdapter(sql1, con);
            ds1.Reset();
            da1.Fill(ds1);
            dt1 = ds1.Tables[0];
            dataGridView2.DataSource = dt1;
            dataGridView2.Columns[0].HeaderText = "Номер продукта";
            dataGridView2.Columns[1].HeaderText = "Номер контракта";
            dataGridView2.Columns[2].HeaderText = "Количество отгруженного";
            dataGridView2.Columns[3].HeaderText = "Сумма отгруженного";
            this.StartPosition = FormStartPosition.CenterScreen;
        }

      
        public class Naclad
        {
            public int id_cnt { get; set; }

            public Naclad(int id)
            {
                this.id_cnt = id;
            }
        }
       

        private void Otgruz_Load(object sender, EventArgs e)
        {
            Update(id_cnt);
        }

        private void dataGridView1_SelectionChanged(object sender, EventArgs e)
        {
            DataGridViewSelectedRowCollection selectedRows = dataGridView1.SelectedRows;
            if (selectedRows.Count > 0)
            {
                DataGridViewRow row = selectedRows[0];
                id_p = Convert.ToInt32(row.Cells[0].Value);
                textBox1.Text = Convert.ToString(row.Cells[2].Value);
                textBox2.Text = Convert.ToString(row.Cells[3].Value);
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            NpgsqlCommand command1 = new NpgsqlCommand("INSERT INTO shipment (id_cnt, id_p, quantity_sh,sum_sh) VALUES (:id_cnt, :id_tovar, :quant, :sum)", con);
            command1.Parameters.AddWithValue("quant", Convert.ToInt32(textBox1.Text));
            command1.Parameters.AddWithValue("sum", Convert.ToInt32(textBox2.Text));
            command1.Parameters.AddWithValue("id_tovar", id_p);
            command1.Parameters.AddWithValue("id_cnt", id_cnt);
            command1.ExecuteNonQuery();
            Update(id_cnt);

            Excel.Application exApp = new Excel.Application();
            Excel.Worksheet wsh = (Excel.Worksheet)exApp.ActiveSheet;
            int i, j;
            for (i = 0; i < dataGridView2.Rows.Count-2; i++)
            {
                for (j = 0; j < dataGridView2.ColumnCount-1; j++)
                {
                    wsh.Cells[i+1, j+1] = dataGridView2[j, i].Value.ToString();
                }
            }
            exApp.Visible = true;
        }

        private void comboBox1_SelectedIndexChanged_1(object sender, EventArgs e)
        {
            Naclad contr = (Naclad)comboBox1.SelectedItem;
            id_cnt = contr.id_cnt;
            Update(id_cnt);
        }


      
    }
}
