﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Npgsql;

namespace Winner2
{
        public partial class client_con : Form
    {
        public NpgsqlConnection con;
        DataTable dt = new DataTable();
        DataSet ds = new DataSet();
        int id;
   

        public client_con(NpgsqlConnection con)
        {
            this.con = con;
            InitializeComponent();
        }

        public void Update()
        {
            String sql = "Select * from client";
            NpgsqlDataAdapter da = new NpgsqlDataAdapter(sql, con);
            ds.Reset();
            da.Fill(ds);
            dt = ds.Tables[0];
            dataGridView1.DataSource = dt;
            dataGridView1.Columns[0].HeaderText = "Номер";
            dataGridView1.Columns[1].HeaderText = "Имя";
            dataGridView1.Columns[2].HeaderText = "Адрес";
            dataGridView1.Columns[3].HeaderText = "Телефон";
            this.StartPosition = FormStartPosition.CenterScreen;
        }
        private void client_con_Load(object sender, EventArgs e)
        {
            Update();
        }

        private void addToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Client f = new Client(con);
            f.ShowDialog();
            Update();
        }

        private void deleteToolStripMenuItem_Click(object sender, EventArgs e)
        {
            const string message = "Ты головой подумал?";
            const string caption = "Form Closing";
            var result = MessageBox.Show(message, caption, MessageBoxButtons.YesNo, MessageBoxIcon.Question);

            // If the no button was pressed ...
            if (result == DialogResult.Yes)
            {
                int id = (int)dataGridView1.CurrentRow.Cells["id_c"].Value;
                NpgsqlCommand command = new NpgsqlCommand("delete from client where id_c = :id", con);
                command.Parameters.AddWithValue("id", id);
                command.ExecuteNonQuery();
                Update();
            }
        }

        private void dataGridView1_SelectionChanged(object sender, EventArgs e)
        {
            DataGridViewSelectedRowCollection selectedRows = dataGridView1.SelectedRows;
            if (selectedRows.Count > 0)
            {
                DataGridViewRow row = selectedRows[0];
                id = Convert.ToInt32(row.Cells[0].Value);
                textBox1.Text = Convert.ToString(row.Cells[1].Value);
                textBox2.Text = Convert.ToString(row.Cells[2].Value);
                textBox3.Text = Convert.ToString(row.Cells[3].Value);
            }
        }

        private void updateToolStripMenuItem_Click(object sender, EventArgs e)
        {
            
            string sql = string.Format("UPDATE client SET name_ = '{0}', addres = '{1}', tel = '{2}' WHERE id_c = {3}", textBox1.Text, textBox2.Text, textBox3.Text, id);
            NpgsqlCommand cmd = new NpgsqlCommand(sql, con);
            cmd.ExecuteNonQuery();
            Update();
            /*
            NpgsqlCommand command = new NpgsqlCommand("INSERT INTO client (name_, addres, tel) VALUES (:name, :adr, :phn) where id_c = :id", con);
            command.Parameters.AddWithValue("name", textBox1.Text);
            command.Parameters.AddWithValue("adr", textBox2.Text);
            command.Parameters.AddWithValue("phn", textBox3.Text);
            command.Parameters.AddWithValue("id", id);
            command.ExecuteNonQuery();
            Update();
            */
        }
    }
}
