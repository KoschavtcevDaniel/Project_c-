﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Npgsql;
using System.Windows.Forms;

namespace Winner2
{
    public partial class Form1 : Form
    {
        public NpgsqlConnection con;

        public void MyLoad()
        {
            this.StartPosition = FormStartPosition.CenterScreen;
            con = new NpgsqlConnection("Server=localhost; Port=5432; UserID=postgres; Password=postpass; Database=postgres");
            con.Open();
        }
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            MyLoad(); 
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Form2 fp = new Form2(con);
            fp.ShowDialog();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            client_con fp = new client_con(con);
            fp.ShowDialog();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Naclad nc = new Naclad(con);
            nc.ShowDialog();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            
        }

        private void button5_Click(object sender, EventArgs e)
        {

        }
    }
}
